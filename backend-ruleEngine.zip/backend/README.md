# Rule Engine Application

## Objective
This is a simple 3-tier rule engine application designed to determine user eligibility based on attributes such as age, department, income, and spend. The system leverages an Abstract Syntax Tree (AST) to dynamically create, combine, and modify rules.

##Scope
The three-tier Rule Engine can be used by businesses such as finance, healthcare, e-commerce, and human resources using predefined rules to evaluate data and achieve good results. Its main features include automating complex processes, enabling real-time decision-making, and encouraging adaptability as regulations can be easily changed without changing the source code. The rules engine simplifies business operations, reduces manual labor, and ensures work by handling everything from compliance checks to fraud detection. The combination of data analytics and machine learning continues to increase the effectiveness of policies by allowing them to adapt and optimize decision-making based on historical data and standards.

## Features
- Define conditional rules and store them as AST.
- Combine multiple rules into a single AST to improve efficiency.
- Evaluate rules against user data in JSON format.

## Data Structure
A Node structure is used to represent the AST with the following fields:
- **type**: Node type ("operator" for AND/OR, "operand" for conditions)
- **left**: Left child Node
- **right**: Right child Node
- **value**: Optional value for operand nodes (e.g., number for comparisons)

## Sample Rules
- Rule 1: `((age > 30 AND department = 'Sales') OR (age < 25 AND department = 'Marketing')) AND (salary > 50000 OR experience > 5)`
- Rule 2: `((age > 30 AND department = 'Marketing')) AND (salary > 20000 OR experience > 5)`

## API Endpoints
### POST /create_rule
Create a rule by sending a rule string as input.

**Example Request:**
```json
{
  "rule_string": "age > 30 AND department = 'Sales'"
}
```

***POST /combine_rules***
Combine multiple rules into a single AST.

Example Request:

```json
{
  "rules": ["rule1", "rule2"]
}
```

***POST /evaluate_rule***
Evaluate a rule against provided user data.

Example Request:

```json
{
  "rule": "combined_rule_ast",
  "data": {
    "age": 35,
    "department": "Sales",
    "salary": 60000,
    "experience": 3
  }
}
```
***Dependencies***
- Java
- Spring Boot 
- JSON libraries
***Database*** (choose as per preference for storing rules, e.g., MySQL, MongoDB)

***Setup Instructions***
Clone the repository:
```bash
git clone <repository-url>
cd rule-engine-ast
```
Install dependencies:
```bash
mvn install
```
Set up the database and configure credentials in application.properties.
Run the application:
```bash
mvn spring-boot:run
```
