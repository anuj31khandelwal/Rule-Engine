package com.engine.rule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
